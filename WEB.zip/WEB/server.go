package main

import (
	"crypto/subtle"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
)

// Visitor tracks a single landing page visit
type Visitor struct {
	IP        string `json:"ip"`
	Timestamp string `json:"timestamp"`
	UA        string `json:"ua"`
}

// SecurityLog tracks administrative authentication anomalies or blocks
type SecurityLog struct {
	Timestamp string `json:"timestamp"`
	IP        string `json:"ip"`
	Event     string `json:"event"`
	Desc      string `json:"desc"`
}

// StatsData stores global page views, download statistics, and lists of logs
type StatsData struct {
	PortableDownloads int           `json:"portableDownloads"`
	SetupDownloads    int           `json:"setupDownloads"`
	TotalPageViews    int           `json:"totalPageViews"`
	Visitors          []Visitor     `json:"visitors"`
	SecurityLogs      []SecurityLog `json:"securityLogs"`
}

// Server configuration
var (
	port        int
	stateFile   string
	staticDir   string
	adminPass   string
	mu          sync.Mutex

	// Brute-force protection trackers
	failedAttempts = make(map[string]int)
	lockouts       = make(map[string]int64)
	securityMu     sync.Mutex

	// Statistics engine config
	statsFile = "web_stats.json"
	stats     StatsData
	statsMu   sync.Mutex

	// Proxy Trust config
	trustProxy bool
)

func main() {
	// Parse CLI flags
	flag.IntVar(&port, "port", 8080, "Web sunucu dinleme portu")
	flag.StringVar(&stateFile, "state", "web_state.json", "Web sitesi icerik JSON dosyasi")
	flag.StringVar(&staticDir, "static", ".", "Statik dosyalarin (index.html) bulundugu dizin")
	flag.StringVar(&adminPass, "password", "ucaklibiskuvi42?", "Yonetim paneli giris sifresi")
	flag.BoolVar(&trustProxy, "trust-proxy", false, "Ters proxy (Nginx, Cloudflare) arkasindaysa IP tespiti icin X-Forwarded-For basligina guven")
	flag.Parse()

	log.Printf("[QBWeb] Sunucu baslatiliyor... Dinleme adresi: http://localhost:%d", port)
	log.Printf("[QBWeb] Statik dizin: %s, Icerik veritabani: %s", staticDir, stateFile)

	// Ensure the state file exists or write default
	ensureStateFile()

	// Load previous stats from database
	loadStats()

	// Start background security map janitor to prevent memory leaks from IP mapping under botnet spam
	go func() {
		for {
			time.Sleep(10 * time.Minute)
			securityMu.Lock()
			now := time.Now().Unix()
			// Clean up expired lockouts
			for ip, expire := range lockouts {
				if now >= expire {
					delete(lockouts, ip)
					delete(failedAttempts, ip)
				}
			}
			// Prune un-lockout failed attempts tracking to prevent memory expansion
			if len(failedAttempts) > 5000 {
				for ip, attempts := range failedAttempts {
					if _, locked := lockouts[ip]; !locked || attempts < 5 {
						delete(failedAttempts, ip)
					}
				}
			}
			securityMu.Unlock()
		}
	}()

	// HTTP Routing
	http.HandleFunc("/api/state", handleStateAPI)
	http.HandleFunc("/api/login", handleLoginAPI)
	http.HandleFunc("/api/admin/stats", handleAdminStatsAPI)

	// Redirect trackers
	http.HandleFunc("/download/portable", handleDownloadPortable)
	http.HandleFunc("/download/setup", handleDownloadSetup)
	
	// Fallback to static file server for index.html
	http.HandleFunc("/", handleStaticFiles)

	// Start server listening
	addr := fmt.Sprintf(":%d", port)
	if err := http.ListenAndServe(addr, nil); err != nil {
		log.Fatalf("[QBWeb] Sunucu baslatilamadi: %v", err)
	}
}

// ensureStateFile makes sure web_state.json is ready
func ensureStateFile() {
	if _, err := os.Stat(stateFile); os.IsNotExist(err) {
		log.Println("[QBWeb] Icerik veritabani bulunamadi, varsayilan olusturuluyor...")
		defaultData := []byte(`{
    "accentColor": "#10b981",
    "portableLink": "https://github.com/tommyvercetti89/qbfile/releases/download/v1.0.0/qbfile-portable.exe",
    "setupLink": "https://github.com/tommyvercetti89/qbfile/releases/download/v1.0.0/qbfile-setup.exe",
    "activeLang": "tr",
    "tr": {
        "badgeText": "v1.0.0 Kararlı Sürüm Yayında - Hemen Paylaşmaya Başlayın",
        "heroTitle": "Tek Tıkla, <span>Ultra Hızlı P2P Paylaşım.</span>",
        "heroDesc": "QBFile; yerel ağınızda veya internet üzerinde hiçbir aracı sunucu olmadan, dosya ve klasörlerinizi doğrudan alıcıya göndermenin en kolay ve en hızlı yoludur. Kurulum gerekmez, dosya boyutu sınırı yoktur.",
        "portableText": "Taşınabilir Exe İndir (.exe)",
        "setupText": "Kurulum Sihirbazı (.exe)",
        "secTitle": "Aracısız, Hızlı ve Özel",
        "secDesc": "Sinyalleşme sunucumuz dahi dosyalarınızın içeriğine asla ulaşamaz. Paylaşım işlemi doğrudan sizin bilgisayarınız ile alıcı bilgisayar arasında gerçekleşir. Verileriniz bulutta kaybolmaz, doğrudan hedefine akar.",
        "secLblKey": "Sıfır Bulut Kaydı",
        "secLblAes": "Doğrudan Cihazdan Cihaza",
        "secLblTunnel": "Maksimum Hız",
        "featSecTitle": "Dosya Paylaşmanın En Doğal Hali",
        "featSecDesc": "Hız ve kolaylık odaklı, modern P2P mühendisliği.",
        "feat1Title": "Zahmetsiz Bağlantı Kurma",
        "feat1Desc": "Karşı tarafın benzersiz ID'sini girin ve anında dosya gönderin veya sohbet etmeye başlayın. IP adresleri veya ağ ayarlarıyla uğraşmanıza gerek kalmaz.",
        "feat2Title": "Sınırsız ve Hızlı Transfer",
        "feat2Desc": "Dosya boyutu sınırlamalarına takılmadan, internet bağlantınızın elverdiği maksimum bant genişliğinde doğrudan aktarım yapın.",
        "feat3Title": "Yerel Güvenli Profil",
        "feat3Desc": "Profil ayarlarınız ve geçmişiniz sadece sizin bilgisayarınızda saklanır. Harici hiçbir sisteme veya üçüncü tarafa veri sızdırılmaz.",
        "footerDesc": "Bu ürün tommyvercetti89 tarafından geliştirilmiş ve Google DeepMind ekibinin ileri düzey yapay zeka kodlama asistanı Antigravity iş birliğiyle tasarlanmıştır."
    },
    "en": {
        "badgeText": "v1.0.0 Stable Release Live - Start Sharing Instantly",
        "heroTitle": "One Click, <span>Ultra-Fast P2P Sharing.</span>",
        "heroDesc": "QBFile is the easiest and fastest way to send files and folders directly to anyone over local networks or the internet, with zero middleman servers. No setup required, no size limits.",
        "portableText": "Download Portable (.exe)",
        "setupText": "Download Setup Wizard (.exe)",
        "secTitle": "Direct, Fast, and Private",
        "secDesc": "Not even the signaling server can access your files. Sharing happens directly between your computer and the receiver. Your data never gets stored in the cloud; it flows directly to its destination.",
        "secLblKey": "Zero Cloud Storage",
        "secLblAes": "Direct Peer-to-Peer",
        "secLblTunnel": "Maximum Speed",
        "featSecTitle": "The Most Natural Way to Share",
        "featSecDesc": "Modern P2P engineering focused on speed and simplicity.",
        "feat1Title": "Effortless Connections",
        "feat1Desc": "Just enter the other person's unique Peer ID and start sharing or chatting instantly. No complex network configuration or IP handling required.",
        "feat2Title": "Unlimited & High-Speed",
        "feat2Desc": "Transfer files of any size without limitations. Data streams directly at the absolute maximum speed allowed by your internet connection.",
        "feat3Title": "Local & Self-Contained",
        "feat3Desc": "Your profile settings and transfer history are kept strictly on your local device. Zero data leakage to external trackers.",
        "footerDesc": "This product is developed by tommyvercetti89 and designed in collaboration with Antigravity, the advanced AI coding assistant from Google DeepMind."
    },
    "updates": [
        {
            "title_tr": "v1.0.0 Kararlı Üretim Sürümü",
            "title_en": "v1.0.0 Stable Production Release",
            "date_tr": "18 Mayıs 2026",
            "date_en": "May 18, 2026",
            "desc_tr": "Uçtan uca şifreli (E2EE) transferler, eliptik eğrili arkadaş doğrulama filtreleri, şifreli profil kasası ve tam yerelleştirilmiş glassmorphism kullanıcı arayüzü ile ilk kararlı sürüm başarıyla yayınlandı.",
            "desc_en": "First stable version successfully launched featuring E2EE transfers, elliptic curve friend verification filters, encrypted profile vault, and fully localized glassmorphism UI.",
            "tags": ["P2P", "E2EE", "Release"]
        },
        {
            "title_tr": "v1.0.0-rc2 Hata Giderme Sürümü",
            "title_en": "v1.0.0-rc2 Bug Fix Release",
            "date_tr": "17 Mayıs 2026",
            "date_en": "May 17, 2026",
            "desc_tr": "UUID tabanlı Peer ID üretimlerindeki Sprintf byte dizilimi hatası giderildi, çevrimdışı arkadaş arayüz kartları otomatik-tamir yeteneği ile donatıldı.",
            "desc_en": "Fixed Sprintf byte formatting issue in UUID-based Peer ID generation and integrated offline friend UI card self-healing mechanism.",
            "tags": ["Fix", "Security", "Core"]
        }
    ]
}`)
		if err := os.WriteFile(stateFile, defaultData, 0644); err != nil {
			log.Printf("[QBWeb] Hata: Varsayilan icerik dosyasi yazilamadi: %v", err)
		}
	}
}

// Helper to extract the request IP address cleanly
func getIP(r *http.Request) string {
	if trustProxy {
		ip := r.Header.Get("X-Forwarded-For")
		if ip != "" {
			return strings.Split(ip, ",")[0]
		}
	}
	parts := strings.Split(r.RemoteAddr, ":")
	return parts[0]
}

// checkLockout returns true if the IP is blocked, sending the appropriate HTTP response
func checkLockout(w http.ResponseWriter, r *http.Request) bool {
	ip := getIP(r)
	securityMu.Lock()
	defer securityMu.Unlock()

	if expire, locked := lockouts[ip]; locked {
		if time.Now().Unix() < expire {
			http.Error(w, "Cok fazla hatali deneme! 15 dakika boyunca engellendiniz.", http.StatusTooManyRequests)
			return true
		}
		// Lockout expired, clean up
		delete(lockouts, ip)
		failedAttempts[ip] = 0
	}
	return false
}

// recordFailure records a failed login attempt for the IP, triggering a lockout if it exceeds 5 attempts
func recordFailure(ip string) {
	securityMu.Lock()
	defer securityMu.Unlock()

	failedAttempts[ip]++
	recordSecurityEvent(ip, "AUTH_FAIL", fmt.Sprintf("Hatalı yönetici şifresi denendi. (Hata: %d/5)", failedAttempts[ip]))
	if failedAttempts[ip] >= 5 {
		lockouts[ip] = time.Now().Add(15 * time.Minute).Unix()
		log.Printf("[QBWeb] GUVENLIK UYARISI: %s IP adresi cok fazla hatali giris denemesi nedeniyle 15 dakika engellendi!", ip)
		recordSecurityEvent(ip, "LOCKOUT", "Çok fazla hatalı deneme nedeniyle IP adresi 15 dakika engellendi.")
	}
}

// recordSuccess resets the failed login attempt counter for the IP
func recordSuccess(ip string) {
	securityMu.Lock()
	defer securityMu.Unlock()
	failedAttempts[ip] = 0
	recordSecurityEvent(ip, "AUTH_SUCCESS", "Yönetici paneline başarıyla giriş yapıldı.")
}

// setSecureHeaders configures modern web security and privacy headers on all responses
func setSecureHeaders(w http.ResponseWriter) {
	w.Header().Set("X-Frame-Options", "DENY")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("X-XSS-Protection", "1; mode=block")
	w.Header().Set("Content-Security-Policy", "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self';")
}

// handleStateAPI processes GET and POST content updates
func handleStateAPI(w http.ResponseWriter, r *http.Request) {
	setSecureHeaders(w)
	// Enable CORS for development flexibility
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
	w.Header().Set("Access-Control-Allow-Methods", "GET, POST, OPTIONS")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	mu.Lock()
	defer mu.Unlock()

	switch r.Method {
	case "GET":
		data, err := os.ReadFile(stateFile)
		if err != nil {
			http.Error(w, "Veritabani okunamadi", http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json; charset=utf-8")
		w.Write(data)

	case "POST":
		ip := getIP(r)
		if checkLockout(w, r) {
			return
		}

		// Check Authorization Header securely with ConstantTimeCompare to prevent timing attacks
		authHeader := r.Header.Get("Authorization")
		if subtle.ConstantTimeCompare([]byte(authHeader), []byte(adminPass)) != 1 {
			recordFailure(ip)
			http.Error(w, "Yetkisiz islem! Gecersiz sifre.", http.StatusUnauthorized)
			return
		}
		recordSuccess(ip)

		// Mitigate Denial of Service (DoS) memory exhaustion: Limit payload to 1 MB max
		r.Body = http.MaxBytesReader(w, r.Body, 1024*1024)

		body, err := io.ReadAll(r.Body)
		if err != nil {
			http.Error(w, "Veri limitini astiniz (Maksimum 1 MB)", http.StatusBadRequest)
			return
		}

		// Validate JSON before saving
		var testMap map[string]interface{}
		if err := json.Unmarshal(body, &testMap); err != nil {
			http.Error(w, "Gecersiz JSON formatı", http.StatusBadRequest)
			return
		}

		// Write fresh customized JSON back to stateFile database
		if err := os.WriteFile(stateFile, body, 0644); err != nil {
			http.Error(w, "Veri kaydedilemedi", http.StatusInternalServerError)
			return
		}

		log.Println("[QBWeb] Web sitesi icerigi yonetici tarafindan güncellendi!")
		recordSecurityEvent(ip, "CONTENT_UPDATE", "Web sitesi görünümü ve içeriği yönetici tarafından güncellendi.")
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"success":true,"message":"Icerik basariyla güncellendi!"}`))

	default:
		http.Error(w, "Metot desteklenmiyor", http.StatusMethodNotAllowed)
	}
}

// handleLoginAPI checks if password matches
func handleLoginAPI(w http.ResponseWriter, r *http.Request) {
	setSecureHeaders(w)
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type")
	w.Header().Set("Access-Control-Allow-Methods", "POST, OPTIONS")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "POST" {
		http.Error(w, "Metot desteklenmiyor", http.StatusMethodNotAllowed)
		return
	}

	ip := getIP(r)
	if checkLockout(w, r) {
		return
	}

	var req struct {
		Password string `json:"password"`
	}

	// Protect login endpoint from buffer overflow or large bodies
	r.Body = http.MaxBytesReader(w, r.Body, 2048)

	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "Gecersiz veri", http.StatusBadRequest)
		return
	}

	// secure authentication timing attack shield
	if subtle.ConstantTimeCompare([]byte(req.Password), []byte(adminPass)) == 1 {
		recordSuccess(ip)
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"success":true,"message":"Giris basarili!"}`))
	} else {
		recordFailure(ip)
		http.Error(w, "Hatalı sifre!", http.StatusUnauthorized)
	}
}

// handleStaticFiles serves the static index.html from WEB folder securely
func handleStaticFiles(w http.ResponseWriter, r *http.Request) {
	setSecureHeaders(w)
	path := filepath.Clean(r.URL.Path)
	if path == "/" || path == "/index.html" {
		recordPageView(getIP(r), r.Header.Get("User-Agent"))
		http.ServeFile(w, r, filepath.Join(staticDir, "index.html"))
		return
	}
	
	// Double Containment Shield against Directory Traversal (escaping web root)
	fullPath := filepath.Join(staticDir, path)
	absStatic, err1 := filepath.Abs(staticDir)
	absFull, err2 := filepath.Abs(fullPath)
	if err1 == nil {
		// Secure prefix check: ensure staticDir ends with OS path separator to prevent sibling bypasses (e.g. site vs site-other)
		if !strings.HasSuffix(absStatic, string(filepath.Separator)) {
			absStatic += string(filepath.Separator)
		}
	}
	if err1 != nil || err2 != nil || !strings.HasPrefix(absFull, absStatic) {
		recordSecurityEvent(getIP(r), "TRAVERSAL", fmt.Sprintf("Dizin aşım denemesi engellendi! Yol: %s", path))
		http.Error(w, "Access Denied / Yetkisiz Erisim", http.StatusForbidden)
		return
	}

	if _, err := os.Stat(fullPath); err == nil {
		http.ServeFile(w, r, fullPath)
		return
	}
	
	// Secure SPA fallback
	http.ServeFile(w, r, filepath.Join(staticDir, "index.html"))
}

// loadStats loads the stats file web_stats.json if it exists
func loadStats() {
	statsMu.Lock()
	defer statsMu.Unlock()
	data, err := os.ReadFile(statsFile)
	if err == nil {
		json.Unmarshal(data, &stats)
	}
	if stats.Visitors == nil {
		stats.Visitors = []Visitor{}
	}
	if stats.SecurityLogs == nil {
		stats.SecurityLogs = []SecurityLog{}
	}
}

// saveStatsLocked writes the stats cache to disk. Caller must hold statsMu.
func saveStatsLocked() {
	data, err := json.MarshalIndent(stats, "", "    ")
	if err == nil {
		os.WriteFile(statsFile, data, 0644)
	}
}

// recordPageView inserts a new visitor record and increments total views
func recordPageView(ip, ua string) {
	statsMu.Lock()
	defer statsMu.Unlock()
	stats.TotalPageViews++

	timestamp := time.Now().Format("2006-01-02 15:04:05")
	stats.Visitors = append([]Visitor{{IP: ip, Timestamp: timestamp, UA: ua}}, stats.Visitors...)
	if len(stats.Visitors) > 100 {
		stats.Visitors = stats.Visitors[:100]
	}
	saveStatsLocked()
}

// recordDownload increments the specific file download metric
func recordDownload(dlType string) {
	statsMu.Lock()
	defer statsMu.Unlock()
	if dlType == "portable" {
		stats.PortableDownloads++
	} else if dlType == "setup" {
		stats.SetupDownloads++
	}
	saveStatsLocked()
}

// recordSecurityEvent logs administrative/auth issues to the stats database
func recordSecurityEvent(ip, event, desc string) {
	statsMu.Lock()
	defer statsMu.Unlock()
	timestamp := time.Now().Format("2006-01-02 15:04:05")
	stats.SecurityLogs = append([]SecurityLog{{Timestamp: timestamp, IP: ip, Event: event, Desc: desc}}, stats.SecurityLogs...)
	if len(stats.SecurityLogs) > 100 {
		stats.SecurityLogs = stats.SecurityLogs[:100]
	}
	saveStatsLocked()
}

// getRedirectURL retrieves the dynamic download URL from web_state.json
func getRedirectURL(dlType string) string {
	mu.Lock()
	defer mu.Unlock()
	data, err := os.ReadFile(stateFile)
	if err != nil {
		if dlType == "portable" {
			return "https://github.com/tommyvercetti89/qbfile/releases/download/v1.0.0/qbfile-portable.exe"
		}
		return "https://github.com/tommyvercetti89/qbfile/releases/download/v1.0.0/qbfile-setup.exe"
	}
	var state map[string]interface{}
	if err := json.Unmarshal(data, &state); err == nil {
		if val, ok := state[dlType+"Link"].(string); ok {
			return val
		}
	}
	if dlType == "portable" {
		return "https://github.com/tommyvercetti89/qbfile/releases/download/v1.0.0/qbfile-portable.exe"
	}
	return "https://github.com/tommyvercetti89/qbfile/releases/download/v1.0.0/qbfile-setup.exe"
}

// handleDownloadPortable registers portable download count and redirects to active release URL
func handleDownloadPortable(w http.ResponseWriter, r *http.Request) {
	recordDownload("portable")
	url := getRedirectURL("portable")
	http.Redirect(w, r, url, http.StatusFound)
}

// handleDownloadSetup registers setup download count and redirects to active release URL
func handleDownloadSetup(w http.ResponseWriter, r *http.Request) {
	recordDownload("setup")
	url := getRedirectURL("setup")
	http.Redirect(w, r, url, http.StatusFound)
}

// handleAdminStatsAPI returns dynamic views, downloads, visitor IPs and security logs
func handleAdminStatsAPI(w http.ResponseWriter, r *http.Request) {
	setSecureHeaders(w)
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	if r.Method != "GET" {
		http.Error(w, "Metot desteklenmiyor", http.StatusMethodNotAllowed)
		return
	}

	ip := getIP(r)
	if checkLockout(w, r) {
		return
	}

	// Validate administrator token securely using ConstantTimeCompare
	authHeader := r.Header.Get("Authorization")
	if subtle.ConstantTimeCompare([]byte(authHeader), []byte(adminPass)) != 1 {
		recordFailure(ip)
		http.Error(w, "Yetkisiz islem! Gecersiz sifre.", http.StatusUnauthorized)
		return
	}
	
	// Fetch all gathered stats
	statsMu.Lock()
	defer statsMu.Unlock()

	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	json.NewEncoder(w).Encode(stats)
}
