# QBFile Web Sunucusu Kurulum ve Çalıştırma Kılavuzu 🚀

Bu klasör, QBFile indirme sayfasını ve dinamik yönetim panelini barındıran Go tabanlı yüksek performanslı web sunucusu dosyalarını içerir.

---

## 📁 Dosya Yapısı

*   `index.html` - Ziyaretçilerin gördüğü web arayüzü ve gizli yönetim paneli.
*   `web_server.exe` - Windows için hazır derlenmiş sunucu dosyası.
*   `web_server_linux_amd64` - Linux (Intel/AMD) sunucular için derlenmiş dosya.
*   `web_server_linux_arm64` - Linux ARM (Raspberry Pi, ARM Sunucular vb.) için derlenmiş dosya.
*   `web_state.json` - Web sitesinin başlıklarını, renklerini ve indirme linklerini tutan veritabanı dosyası (ilk çalıştırmada otomatik oluşur).
*   `web_stats.json` - Ziyaretçi IP'lerini, indirme sayılarını ve güvenlik loglarını tutan dosya (otomatik oluşur).

---

## 🚀 Çalıştırma Talimatları

Sunucunun çalışabilmesi için **`index.html` dosyası ile çalıştırdığınız executable (ikili) dosya aynı klasörde yer almalıdır.**

### 1. Windows Üzerinde Çalıştırma
Komut satırını (CMD veya PowerShell) açıp klasörün içine girin ve aşağıdaki komutla başlatın:
```cmd
web_server.exe -port 12130
```

### 2. Linux Üzerinde Çalıştırma (AMD64 / ARM64)
Dosyayı sunucunuza yükledikten sonra terminalden şu adımları izleyin:
1.  **Çalıştırma Yetkisi Verin:**
    ```bash
    chmod +x web_server_linux_amd64
    ```
2.  **Sunucuyu Başlatın:**
    ```bash
    ./web_server_linux_amd64 -port 12130
    ```

*(Not: Eğer ARM mimarili bir sunucu kullanıyorsanız `web_server_linux_arm64` dosyasını yetkilendirip çalıştırın.)*

---

## ⚙️ Başlangıç Parametreleri (Opsiyonel)

Sunucu çalıştırılırken aşağıdaki parametreler kullanılabilir:
*   `-port` : Sunucunun dinleyeceği port numarası (Varsayılan: `8080`).
*   `-password` : Yönetim paneli giriş şifresi (Varsayılan: `ucaklibiskuvi42?`).
*   `-state` : İçerik veritabanının kaydedileceği dosya yolu (Varsayılan: `web_state.json`).
*   `-trust-proxy` : Nginx veya Cloudflare arkasında çalışırken IP kaba kuvvet korumasının atlatılmaması için gerçek kullanıcı IP tespitini aktif eder (Varsayılan: `false`).

**Örnek Özelleştirilmiş Başlatma:**
```bash
./web_server_linux_amd64 -port 9090 -password "benim_ozel_sifrem123" -trust-proxy
```

---

## 🔒 Güvenlik & HTTPS (SSL) Yapılandırması

Yönetici şifresinin internette düz metin olarak çalınmasını engellemek için, **kamusal (public) IP/alan adları üzerinden yapılan HTTP bağlantılarında yönetici girişi engellenir.** 

*   Yerel ağda (WiFi) bilgisayar adı veya yerel IP'ler (`192.168.x.x` vb.) üzerinden HTTP ile bağlanıp giriş yapabilirsiniz.
*   Ancak sunucuyu dış dünyaya (internete) açtığınızda **HTTPS (SSL)** kullanmanız zorunludur.
*   **Tavsiye edilen yöntem:** Sunucuyu `12130` (veya istediğiniz başka bir yerel portta) çalıştırıp önüne **Nginx**, **Caddy** veya **Cloudflare Tunnel** kurarak gelen HTTPS isteklerini sunucu portuna yönlendirmenizdir (Reverse Proxy).

---

## 🎨 Yönetim Paneline Giriş

1.  Web tarayıcınızdan sitenin kurulu olduğu adrese gidin.
2.  Sol üst köşedeki **QBFile** logosuna **20 kez ardışık olarak tıklayın**.
3.  Karşınıza gelen ekranda yönetici şifresini girerek panelinizi kontrol edebilirsiniz.
